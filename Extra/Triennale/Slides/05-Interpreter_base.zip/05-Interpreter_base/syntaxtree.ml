(* identifiers *)
type ide = Ide of string

(* arithmetical expressions *)
type aexp  =
      N of int
    | R of float
    | Ident of ide
    | Sum of aexp * aexp
    | Sub of aexp * aexp
    | Mul  of  aexp * aexp
    | Div  of  aexp * aexp

(* boolean expressions *)
type bexp =
      B of bool
    | Equ of aexp * aexp
    | LE of  aexp * aexp
    | LT of  aexp * aexp
    | Not of bexp
    | And of bexp * bexp
    | Or of bexp * bexp

(* left expressions *)
type lexp = LVar of ide

(* commands *)
type cmd =
      Ass of lexp * aexp
    | Blk of cmd list
    | Ite of bexp * cmd * cmd
    | While of bexp * cmd
    | For of ide * aexp * aexp * cmd
    | Write of aexp

(* declarations *)
type bType = Int | Float

type gType =
      Basic of bType
    | Const of bType * aexp

type dec = Dec of ide * gType

(* programs *)
type program = Program of dec list * cmd
