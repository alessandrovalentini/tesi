(* (2003)Originale ML(Marco Pistore & Floriano Zini) *)
(*    (2004)Estensione OCAML(Fabrizio Lazzarotto)    *)
(*          (2007)Revisione (Stefano Schivo)         *)
(*	        (2011) Revision (Nataliia Bielova)   *)
(*	        (2012) Revision (Michele Caceffo)   *)

open Syntaxtree;;
(*** INTERPRETER DOMAINS ***)

(* memory *)
type loc = Loc of int
type value =
      ValueInt of int
    | ValueFloat of float

type store = loc -> value

type env_entry = Var of loc | Val of value

type env = ide -> env_entry

(* exception *)
exception NO_MEM
exception NO_IDE
exception SYNTAX
exception DIFFERENT_TYPE_OPERATION
exception DIFFERENT_TYPE_ASSIGNATION
(******************************)

(* THE INTERPRETER *)

(* utility functions *)
let initenv (x:ide):env_entry = raise NO_IDE
let initmem (x:loc):value = raise NO_MEM
let updatemem ((s:store), addr, (v:value)) :store = function
    x -> if (x = addr) then v else s(x)

let updateenv ((e:env), id, (v:env_entry)) :env = function
    y -> if (y = id) then v else e(y)

let newmem (s: store) : int =   
    let rec aux n =
        try (let isFree=s(Loc(n)) in aux(n+1)) with NO_MEM -> n (* isFree is used only to read the memory at the location n, so to see whether that location is non-valid (which means free) *)
    in aux 0


(* evaluation of arithmetical expressions *)
let rec eval_aexp (e:aexp) (r:env) (s:store) : value = match e with
      N(n)      ->  ValueInt(n)
    | R(n)      ->  ValueFloat(n)
    | Ident(i)  ->  (
                     match r(i) with
                          Var(l) -> s(l)
                        | Val(v) -> v
                    )
    
    | Sum (a,b) -> aexp_op_fun a b r s ( + ) ( +. )
    
    | Sub (a,b) -> aexp_op_fun a b r s ( - ) ( -. )
    
    | Mul (a,b) -> aexp_op_fun a b r s ( * ) ( *. )
    
    | Div (a,b) -> aexp_op_fun a b r s ( / ) ( /. )


and aexp_op_fun  (a:aexp) (b:aexp) (r:env) (s:store) fi fr = 
    let aValue = (eval_aexp a r s)
        and bValue = (eval_aexp b r s)
    in (
         match aValue with 
             ValueInt(op1)      -> (
                                     match bValue with
                                          ValueInt(op2) -> ValueInt(fi op1 op2)
                                        | _ -> raise DIFFERENT_TYPE_OPERATION
                                    )
            | ValueFloat(op1)   -> (
                                     match bValue with
                                          ValueFloat(op2) -> ValueFloat(fr op1 op2)
                                        | _ -> raise DIFFERENT_TYPE_OPERATION
                                    )
        )


let rec eval_bexp (e:bexp) (r:env) (s:store) = match e with
      B(b)      ->  b
    | And (a,b) ->  ((eval_bexp a r s ) && (eval_bexp b r s ))
    | Or  (a,b) ->  ((eval_bexp a r s ) || (eval_bexp b r s ))
    | Equ (a,b) ->  ((eval_aexp a r s )  = (eval_aexp b r s ))
    | LE  (a,b) ->  ((eval_aexp a r s ) <= (eval_aexp b r s ))
    | LT  (a,b) ->  ((eval_aexp a r s )  < (eval_aexp b r s ))
    | Not (a)   ->  (not(eval_bexp a r s ))



(* evaluation of declarations *)
let rec dec_eval (d:dec list) (r:env) (s: store) = match d with
      []                        ->  (r,s)
    | Dec(x,Basic(bType))::decls ->  let newaddr = newmem s
                                    in (
                                         match bType with
                                              Int   -> dec_eval decls (updateenv(r,x,Var(Loc(newaddr)))) (updatemem(s,Loc(newaddr),ValueInt(0)))
                                            | Float -> dec_eval decls (updateenv(r,x,Var(Loc(newaddr)))) (updatemem(s,Loc(newaddr),ValueFloat(0.0)))
                                        )
    | Dec(x,Const(bType,value_exp))::decls  
                                ->  let value = eval_aexp value_exp r s
                                    in 
                                    (
                                      match bType with
                                           Int  -> 
                                            (
                                             match value with
                                                  ValueInt(v) -> dec_eval decls (updateenv(r,x,Val(ValueInt(v)))) s
                                                | ValueFloat(v) -> raise DIFFERENT_TYPE_ASSIGNATION
                                            )
                                         | Float->
                                            (
                                             match value with
                                                  ValueFloat(v) -> dec_eval decls (updateenv(r,x,Val(ValueFloat(v)))) s
                                                | ValueInt(v) -> raise DIFFERENT_TYPE_ASSIGNATION
                                            )
                                    )


(* execution of commands *)
let rec exec (c: cmd) (r: env) (s: store) = match c with
    Ass(i,e)        ->  let ret = eval_aexp e r s
                        in 
                        (
                         match i with
                              LVar(id)  -> match r(id) with
                                              Var(l)    -> updatemem(s,l,ret)
                                            | _         -> raise SYNTAX
                        )
    | Blk([])       ->  s
    | Blk(x::y)     ->  exec (Blk(y)) r (exec x r s)
    | Ite(b,c1,c2)  ->  if (eval_bexp b r s) then (exec c1 r s)
                        else (exec c2 r s)
    | While(b,c)    ->  if (not(eval_bexp b r s)) then s
                        else
                            let s'' = exec c r s
                            in (exec (While(b,c)) r s'')
    | For(i,valmin_exp,valmax_exp,c) 
                    ->  let valmin = eval_aexp valmin_exp r s
                        and update_counter l s =
                            match s(l) with
                              ValueInt(n) -> updatemem(s, l, ValueInt(n + 1))
                            | ValueFloat(f) -> updatemem(s, l, ValueFloat(f +. 1.0))
                        in 
                        (
                         match r(i) with
                              Var(l) -> 
                                (
                                let s0 = updatemem(s, l, valmin)
                                in
                                    let rec exec_for s =
                                        let s' = exec c r s
                                        in
                                            let ret = eval_bexp (LT(Ident(i), valmax_exp)) r s'
                                            in
                                                if (ret) then exec_for (update_counter l s')
                                                else s'
                                    in exec_for s0
                                )
                            | _ -> raise SYNTAX
                        )
    | Write(e)      ->  let ret = (eval_aexp e r s)
                        in
                        (
                         match ret with
                              ValueInt(op1) -> print_int(op1); print_string "\n";s
                            | ValueFloat(op1) -> print_float(op1); print_string "\n";s
                        )


(* evaluation of programs *)
let run (Program(vars,com)) =   let (r,s) = dec_eval vars initenv initmem
                                in (exec com r s)
